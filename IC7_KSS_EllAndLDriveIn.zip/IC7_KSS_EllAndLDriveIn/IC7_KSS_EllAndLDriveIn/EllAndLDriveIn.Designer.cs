﻿namespace IC7_KSS_EllAndLDriveIn
{
    partial class EllAndLDriveIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.friedFishMiniTextBox = new System.Windows.Forms.TextBox();
            this.friedShrimpMiniTextBox = new System.Windows.Forms.TextBox();
            this.friedFishRegTextBox = new System.Windows.Forms.TextBox();
            this.friedShrimpRegTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.teriyakiSteakMiniTextBox = new System.Windows.Forms.TextBox();
            this.teriyakiSteakRegTextBox = new System.Windows.Forms.TextBox();
            this.hamburgerSteakMiniTextBox = new System.Windows.Forms.TextBox();
            this.locoMocoRegTextBox = new System.Windows.Forms.TextBox();
            this.locoMocoMiniTextBox = new System.Windows.Forms.TextBox();
            this.hamburgerSteakRegTextBox = new System.Windows.Forms.TextBox();
            this.bBQShortRibsRegTextBox = new System.Windows.Forms.TextBox();
            this.bBQShortRibsMiniTextBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.subtotalLabel = new System.Windows.Forms.Label();
            this.taxLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(101, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Seafood Plates:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Fried Fish ($6.95/$8.95)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(79, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Fried Shrimp ($6.95/$8.95)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(498, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Mini";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(555, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Reg";
            // 
            // friedFishMiniTextBox
            // 
            this.friedFishMiniTextBox.Location = new System.Drawing.Point(457, 93);
            this.friedFishMiniTextBox.Name = "friedFishMiniTextBox";
            this.friedFishMiniTextBox.Size = new System.Drawing.Size(100, 20);
            this.friedFishMiniTextBox.TabIndex = 5;
            // 
            // friedShrimpMiniTextBox
            // 
            this.friedShrimpMiniTextBox.Location = new System.Drawing.Point(457, 132);
            this.friedShrimpMiniTextBox.Name = "friedShrimpMiniTextBox";
            this.friedShrimpMiniTextBox.Size = new System.Drawing.Size(100, 20);
            this.friedShrimpMiniTextBox.TabIndex = 6;
            // 
            // friedFishRegTextBox
            // 
            this.friedFishRegTextBox.Location = new System.Drawing.Point(564, 93);
            this.friedFishRegTextBox.Name = "friedFishRegTextBox";
            this.friedFishRegTextBox.Size = new System.Drawing.Size(100, 20);
            this.friedFishRegTextBox.TabIndex = 7;
            // 
            // friedShrimpRegTextBox
            // 
            this.friedShrimpRegTextBox.Location = new System.Drawing.Point(564, 132);
            this.friedShrimpRegTextBox.Name = "friedShrimpRegTextBox";
            this.friedShrimpRegTextBox.Size = new System.Drawing.Size(100, 20);
            this.friedShrimpRegTextBox.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(104, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Beef Plates:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(79, 298);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Teriyaki Steak ($5.95/$7.25)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(79, 341);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(158, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Hamburger Steak ($5.95/$7.25)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(79, 374);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Loco Moco ($5.95/$7.25)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(79, 407);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(149, 13);
            this.label10.TabIndex = 13;
            this.label10.Text = "BBQ Short Ribs ($5.95/$7.25)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(501, 259);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(26, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "Mini";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(558, 258);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 13);
            this.label12.TabIndex = 15;
            this.label12.Text = "Reg";
            // 
            // teriyakiSteakMiniTextBox
            // 
            this.teriyakiSteakMiniTextBox.Location = new System.Drawing.Point(457, 291);
            this.teriyakiSteakMiniTextBox.Name = "teriyakiSteakMiniTextBox";
            this.teriyakiSteakMiniTextBox.Size = new System.Drawing.Size(100, 20);
            this.teriyakiSteakMiniTextBox.TabIndex = 16;
            // 
            // teriyakiSteakRegTextBox
            // 
            this.teriyakiSteakRegTextBox.Location = new System.Drawing.Point(564, 291);
            this.teriyakiSteakRegTextBox.Name = "teriyakiSteakRegTextBox";
            this.teriyakiSteakRegTextBox.Size = new System.Drawing.Size(100, 20);
            this.teriyakiSteakRegTextBox.TabIndex = 17;
            // 
            // hamburgerSteakMiniTextBox
            // 
            this.hamburgerSteakMiniTextBox.Location = new System.Drawing.Point(457, 334);
            this.hamburgerSteakMiniTextBox.Name = "hamburgerSteakMiniTextBox";
            this.hamburgerSteakMiniTextBox.Size = new System.Drawing.Size(100, 20);
            this.hamburgerSteakMiniTextBox.TabIndex = 18;
            // 
            // locoMocoRegTextBox
            // 
            this.locoMocoRegTextBox.Location = new System.Drawing.Point(564, 367);
            this.locoMocoRegTextBox.Name = "locoMocoRegTextBox";
            this.locoMocoRegTextBox.Size = new System.Drawing.Size(100, 20);
            this.locoMocoRegTextBox.TabIndex = 19;
            // 
            // locoMocoMiniTextBox
            // 
            this.locoMocoMiniTextBox.Location = new System.Drawing.Point(457, 367);
            this.locoMocoMiniTextBox.Name = "locoMocoMiniTextBox";
            this.locoMocoMiniTextBox.Size = new System.Drawing.Size(100, 20);
            this.locoMocoMiniTextBox.TabIndex = 20;
            // 
            // hamburgerSteakRegTextBox
            // 
            this.hamburgerSteakRegTextBox.Location = new System.Drawing.Point(564, 334);
            this.hamburgerSteakRegTextBox.Name = "hamburgerSteakRegTextBox";
            this.hamburgerSteakRegTextBox.Size = new System.Drawing.Size(100, 20);
            this.hamburgerSteakRegTextBox.TabIndex = 21;
            // 
            // bBQShortRibsRegTextBox
            // 
            this.bBQShortRibsRegTextBox.Location = new System.Drawing.Point(564, 400);
            this.bBQShortRibsRegTextBox.Name = "bBQShortRibsRegTextBox";
            this.bBQShortRibsRegTextBox.Size = new System.Drawing.Size(100, 20);
            this.bBQShortRibsRegTextBox.TabIndex = 22;
            // 
            // bBQShortRibsMiniTextBox
            // 
            this.bBQShortRibsMiniTextBox.Location = new System.Drawing.Point(457, 400);
            this.bBQShortRibsMiniTextBox.Name = "bBQShortRibsMiniTextBox";
            this.bBQShortRibsMiniTextBox.Size = new System.Drawing.Size(100, 20);
            this.bBQShortRibsMiniTextBox.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(79, 455);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(39, 13);
            this.label13.TabIndex = 24;
            this.label13.Text = "Totals:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(79, 495);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 13);
            this.label14.TabIndex = 25;
            this.label14.Text = "Subtotal:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(79, 518);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(28, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "Tax:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(79, 542);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(34, 13);
            this.label16.TabIndex = 27;
            this.label16.Text = "Total:";
            // 
            // subtotalLabel
            // 
            this.subtotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.subtotalLabel.Location = new System.Drawing.Point(258, 484);
            this.subtotalLabel.Name = "subtotalLabel";
            this.subtotalLabel.Size = new System.Drawing.Size(90, 23);
            this.subtotalLabel.TabIndex = 28;
            // 
            // taxLabel
            // 
            this.taxLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.taxLabel.Location = new System.Drawing.Point(258, 517);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(90, 24);
            this.taxLabel.TabIndex = 29;
            // 
            // totalLabel
            // 
            this.totalLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalLabel.Location = new System.Drawing.Point(258, 558);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(90, 23);
            this.totalLabel.TabIndex = 30;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(466, 484);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 31;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(467, 518);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 32;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(466, 558);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 33;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // EllAndLDriveIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 644);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.taxLabel);
            this.Controls.Add(this.subtotalLabel);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.bBQShortRibsMiniTextBox);
            this.Controls.Add(this.bBQShortRibsRegTextBox);
            this.Controls.Add(this.hamburgerSteakRegTextBox);
            this.Controls.Add(this.locoMocoMiniTextBox);
            this.Controls.Add(this.locoMocoRegTextBox);
            this.Controls.Add(this.hamburgerSteakMiniTextBox);
            this.Controls.Add(this.teriyakiSteakRegTextBox);
            this.Controls.Add(this.teriyakiSteakMiniTextBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.friedShrimpRegTextBox);
            this.Controls.Add(this.friedFishRegTextBox);
            this.Controls.Add(this.friedShrimpMiniTextBox);
            this.Controls.Add(this.friedFishMiniTextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "EllAndLDriveIn";
            this.Text = "Ell And L Drive-In";
            this.Load += new System.EventHandler(this.EllAndLDriveIn_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox friedFishMiniTextBox;
        private System.Windows.Forms.TextBox friedShrimpMiniTextBox;
        private System.Windows.Forms.TextBox friedFishRegTextBox;
        private System.Windows.Forms.TextBox friedShrimpRegTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox teriyakiSteakMiniTextBox;
        private System.Windows.Forms.TextBox teriyakiSteakRegTextBox;
        private System.Windows.Forms.TextBox hamburgerSteakMiniTextBox;
        private System.Windows.Forms.TextBox locoMocoRegTextBox;
        private System.Windows.Forms.TextBox locoMocoMiniTextBox;
        private System.Windows.Forms.TextBox hamburgerSteakRegTextBox;
        private System.Windows.Forms.TextBox bBQShortRibsRegTextBox;
        private System.Windows.Forms.TextBox bBQShortRibsMiniTextBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label subtotalLabel;
        private System.Windows.Forms.Label taxLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

