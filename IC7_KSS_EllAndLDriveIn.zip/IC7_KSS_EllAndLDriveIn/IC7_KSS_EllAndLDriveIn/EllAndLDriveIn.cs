﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC7_KSS_EllAndLDriveIn
{
    public partial class EllAndLDriveIn : Form
    {
        //global level for constants
        const decimal FRIED_FISH_PRICE_MINI = 6.95m;
        const decimal FRIED_FISH_PRICE_REG = 8.95m;
        const decimal FRIED_SHRIMP_MINI = 6.95m;
        const decimal FRIED_SHRIMP_REG = 8.95m;
        const decimal TERIYAKI_STEAK_MINI = 5.95m;
        const decimal TERIYAKI_STEAK_REG = 7.25m;
        const decimal HAMBURGER_STEAK_MINI = 5.95m;
        const decimal HAMBURGER_STEAK_REG = 7.25m;
        const decimal LOCO_MOCO_MINI = 5.95m;
        const decimal LOCO_MOCO_REG = 7.25m;
        const decimal BBQ_
        public EllAndLDriveIn()
        {
            InitializeComponent();
        }

        private void EllAndLDriveIn_Load(object sender, EventArgs e)
        {
            friedFishMiniTextBox.Text = "0";
            friedFishRegTextBox.Text = "0";
            friedShrimpMiniTextBox.Text = "0";
            friedShrimpRegTextBox.Text = "0";
            teriyakiSteakMiniTextBox.Text = "0";
            teriyakiSteakRegTextBox.Text = "0";
            hamburgerSteakMiniTextBox.Text = "0";
            hamburgerSteakRegTextBox.Text = "0";
            locoMocoMiniTextBox.Text = "0";
            locoMocoRegTextBox.Text = "0";
            bBQShortRibsMiniTextBox.Text = "0";
            bBQShortRibsRegTextBox.Text = "0";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            friedFishMiniTextBox.Text = "0";
            friedFishRegTextBox.Text = "0";
            friedShrimpMiniTextBox.Text = "0";
            friedShrimpRegTextBox.Text = "0";
            teriyakiSteakMiniTextBox.Text = "0";
            teriyakiSteakRegTextBox.Text = "0";
            hamburgerSteakMiniTextBox.Text = "0";
            hamburgerSteakRegTextBox.Text = "0";
            locoMocoMiniTextBox.Text = "0";
            locoMocoRegTextBox.Text = "0";
            bBQShortRibsMiniTextBox.Text = "0";
            bBQShortRibsRegTextBox.Text = "0";
            subtotalLabel.Text = "";
            taxLabel.Text = "";
            totalLabel.Text = "";
        }
    }
}
